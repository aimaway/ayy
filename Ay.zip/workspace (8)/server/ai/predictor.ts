import { v4 as uuidv4 } from 'uuid';
import { getAllRisks, getAssetById, createAIAction, createTestResult, getActionsByRisk, getAllActions as getAllActionsFn } from '../database';
import type { Risk, AIAction, Asset, TestResult } from '../types';

/**
 * AI Prediction Engine
 * Analyzes risks and generates optimal security actions with reasoning,
 * safety verification, and evidence collection.
 */

// Action templates mapped to risk patterns
const ACTION_TEMPLATES: Record<string, {
  type: AIAction['actionType'];
  titleGen: (risk: Risk, asset: Asset) => string;
  titleArGen: (risk: Risk, asset: Asset) => string;
  descGen: (risk: Risk, asset: Asset) => string;
  descArGen: (risk: Risk, asset: Asset) => string;
  reasoningGen: (risk: Risk, asset: Asset) => string;
  reasoningArGen: (risk: Risk, asset: Asset) => string;
  evidenceGen: (risk: Risk, asset: Asset) => string[];
  evidenceArGen: (risk: Risk, asset: Asset) => string[];
  testsGen: (risk: Risk, asset: Asset) => Array<{ name: string; nameAr: string; details: string; detailsAr: string }>;
}> = {
  'rce|remote code execution|execution': {
    type: 'patch',
    titleGen: (r, a) => `Patch ${a.name} to fix ${r.cve || 'RCE vulnerability'}`,
    titleArGen: (r, a) => `ترقيع ${a.name} لإصلاح ${r.cve || 'ثغرة التنفيذ عن بعد'}`,
    descGen: (r, a) => `Apply security patch to ${a.name} (${a.ip}) to remediate ${r.title}`,
    descArGen: (r, a) => `تطبيق رقعة أمنية على ${a.name} (${a.ip}) لمعالجة ${r.titleAr}`,
    reasoningGen: (r, a) => `Remote code execution vulnerabilities allow attackers to execute arbitrary code on the system. This is the highest priority remediation as it can lead to full system compromise. Patching eliminates the attack vector entirely.`,
    reasoningArGen: (r, a) => `ثغرات التنفيذ عن بعد تسمح للمهاجمين بتنفيذ أكواد عشوائية على النظام. هذا هو أولوية العلاج القصوى لأنه يمكن أن يؤدي إلى اختراق كامل للنظام. الترقيع يزيل ناقل الهجوم تماماً.`,
    evidenceGen: (r, a) => [
      `CVE confirmed in NVD database with CVSS ${r.cvssScore}`,
      `Patch tested in isolated staging environment`,
      `No breaking changes expected for ${a.os || 'this system'}`,
      `Backup snapshot created before patching`,
      `Rollback procedure documented and tested`
    ],
    evidenceArGen: (r, a) => [
      `CVE مؤكدة في قاعدة بيانات NVD مع CVSS ${r.cvssScore}`,
      `تم اختبار الرقعة في بيئة معزولة`,
      `لا يتوقع حدوث تغييرات جذرية لـ ${a.os || 'هذا النظام'}`,
      `تم إنشاء لقطة احتياطية قبل الترقيع`,
      `إجراء التراجع موثق ومختبر`
    ],
    testsGen: (r, a) => [
      { name: 'Version Verification', nameAr: 'التحقق من الإصدار', details: `Verified ${a.name} updated to patched version`, detailsAr: `تم التحقق من تحديث ${a.name} إلى الإصدار المرقع` },
      { name: 'Service Availability', nameAr: 'توفر الخدمة', details: 'HTTP 200 OK on all endpoints after patch', detailsAr: 'HTTP 200 OK على جميع نقاط النهاية بعد الترقيع' },
      { name: 'Vulnerability Re-scan', nameAr: 'إعادة فحص الثغرة', details: `${r.cve || 'Vulnerability'} no longer detected`, detailsAr: `${r.cve || 'الثغرة'} لم تعد مكتشفة` },
      { name: 'Configuration Integrity', nameAr: 'سلامة التكوين', details: 'All existing configurations preserved', detailsAr: 'جميع التكوينات الحالية محفوظة' },
    ],
  },
  'sql injection|injection': {
    type: 'remediate',
    titleGen: (r, a) => `Implement WAF rules and input validation on ${a.name}`,
    titleArGen: (r, a) => `تطبيق قواعد WAF والتحقق من المدخلات على ${a.name}`,
    descGen: (r, a) => `Deploy Web Application Firewall rules and implement parameterized queries on ${a.name}`,
    descArGen: (r, a) => `نشر قواعد جدار تطبيقات الويب وتنفيذ استعلامات مُعامَلة على ${a.name}`,
    reasoningGen: (r, a) => `SQL injection allows attackers to manipulate database queries. Defense-in-depth approach with WAF + parameterized queries provides multiple layers of protection.`,
    reasoningArGen: (r, a) => `حقن SQL يسمح للمهاجمين بالتلاعب باستعلامات قاعدة البيانات. نهج الدفاع المتعدد الطبقات مع WAF + الاستعلامات المُعامَلة يوفر طبقات حماية متعددة.`,
    evidenceGen: (r, a) => [
      'WAF rules tested against known SQL injection payloads',
      'Parameterized queries implemented in application code',
      'Input validation regex patterns verified',
      'No false positives detected in staging traffic',
      'Database access logs monitored for suspicious queries'
    ],
    evidenceArGen: (r, a) => [
      'تم اختبار قواعد WAF ضد حمولات حقن SQL معروفة',
      'تم تنفيذ استعلامات مُعامَلة في كود التطبيق',
      'تم التحقق من أنماط regex للتحقق من المدخلات',
      'لم يتم اكتشاف إيجابيات خاطئة في حركة مرور التطوير',
      'مراقبة سجلات وصول قاعدة البيانات للاستعلامات المشبوهة'
    ],
    testsGen: (r, a) => [
      { name: 'SQL Injection Payload Test', nameAr: 'اختبار حمولة حقن SQL', details: 'All common SQL injection payloads blocked', detailsAr: 'تم حظر جميع حمولات حقن SQL الشائعة' },
      { name: 'Application Functionality', nameAr: 'وظائف التطبيق', details: 'All application features working normally', detailsAr: 'جميع ميزات التطبيق تعمل بشكل طبيعي' },
      { name: 'WAF Rule Effectiveness', nameAr: 'فعالية قواعد WAF', details: 'WAF correctly blocking malicious requests', detailsAr: 'WAF يحظر الطلبات الخبيثة بشكل صحيح' },
    ],
  },
  'unauthorized|authentication|brute force|access': {
    type: 'block',
    titleGen: (r, a) => `Implement account lockout and IP blocking on ${a.name}`,
    titleArGen: (r, a) => `تطبيق قفل الحساب وحظر IP على ${a.name}`,
    descGen: (r, a) => `Configure account lockout policy (5 attempts, 30min lockout) and implement IP-based rate limiting on ${a.name}`,
    descArGen: (r, a) => `تهيئة سياسة قفل الحساب (5 محاولات، قفل 30 دقيقة) وتنفيذ تحديد معدل بناءً على IP على ${a.name}`,
    reasoningGen: (r, a) => `Unauthorized access attempts indicate active targeting. Account lockout + IP blocking provides immediate protection while maintaining legitimate access.`,
    reasoningArGen: (r, a) => `محاولات الوصول غير المصرح تشير إلى استهداف نشط. قفل الحساب + حظر IP يوفر حماية فورية مع الحفاظ على الوصول المشروع.`,
    evidenceGen: (r, a) => [
      'Account lockout threshold tested with legitimate credentials',
      'IP blocking rules verified against known attack sources',
      'Whitelist configured for admin/VPN IPs',
      'Alert notifications configured for lockout events',
      'No impact on normal user workflows verified'
    ],
    evidenceArGen: (r, a) => [
      'تم اختبار حد قفل الحساب ببيانات اعتماد مشروعة',
      'تم التحقق من قواعد حظر IP ضد مصادر الهجوم المعروفة',
      'تم تكوين القائمة البيضاء لـ IPs المسؤول/VPN',
      'تم تكوين إشعارات التنبيه لأحداث القفل',
      'تم التحقق من عدم التأثير على سير عمل المستخدم العادي'
    ],
    testsGen: (r, a) => [
      { name: 'Lockout Threshold Test', nameAr: 'اختبار حد القفل', details: 'Account locks after 5 failed attempts', detailsAr: 'يتم قفل الحساب بعد 5 محاولات فاشلة' },
      { name: 'Legitimate Access Test', nameAr: 'اختبار الوصول المشروع', details: 'Valid credentials still work normally', detailsAr: 'بيانات الاعتماد الصالحة لا تزال تعمل بشكل طبيعي' },
      { name: 'IP Blocking Verification', nameAr: 'التحقق من حظر IP', details: 'Blocked IPs cannot access the system', detailsAr: 'IPs المحظورة لا يمكنها الوصول للنظام' },
    ],
  },
  'malware|trojan|ransomware|virus': {
    type: 'isolate',
    titleGen: (r, a) => `Isolate ${a.name} and initiate malware remediation`,
    titleArGen: (r, a) => `عزل ${a.name} وبدء علاج البرمجيات الخبيثة`,
    descGen: (r, a) => `Immediately isolate ${a.name} from network, run full malware scan, and remove detected threats`,
    descArGen: (r, a) => `عزل ${a.name} فوراً من الشبكة، تشغيل فحص شامل للبرمجيات الخبيثة، وإزالة التهديدات المكتشفة`,
    reasoningGen: (r, a) => `Active malware requires immediate isolation to prevent lateral movement and data exfiltration. Network isolation is the fastest way to contain the threat.`,
    reasoningArGen: (r, a) => `البرمجيات الخبيثة النشطة تتطلب عزلاً فورياً لمنع الحركة الجانبية وتسريب البيانات. عزل الشبكة هو أسرع طريقة لاحتواء التهديد.`,
    evidenceGen: (r, a) => [
      'Network isolation verified - no outbound connections possible',
      'Malware scan completed with threat removal confirmed',
      'System integrity check passed post-remediation',
      'No lateral movement detected in network logs',
      'Forensic image preserved for analysis'
    ],
    evidenceArGen: (r, a) => [
      'تم التحقق من عزل الشبكة - لا توجد اتصالات صادرة ممكنة',
      'اكتمل فحص البرمجيات الخبيثة مع تأكيد إزالة التهديد',
      'نجح فحص سلامة النظام بعد العلاج',
      'لم يتم اكتشاف حركة جانبية في سجلات الشبكة',
      'تم حفظ صورة جنائية للتحليل'
    ],
    testsGen: (r, a) => [
      { name: 'Network Isolation Test', nameAr: 'اختبار عزل الشبكة', details: 'System cannot reach external networks', detailsAr: 'النظام لا يمكنه الوصول للشبكات الخارجية' },
      { name: 'Malware Scan Results', nameAr: 'نتائج فحص البرمجيات الخبيثة', details: 'Full scan completed - no threats detected', detailsAr: 'اكتمل الفحص الشامل - لم يتم اكتشاف تهديدات' },
      { name: 'System Integrity Check', nameAr: 'فحص سلامة النظام', details: 'All system files match known-good hashes', detailsAr: 'جميع ملفات النظام تطابق التجزئات المعروفة الجيدة' },
    ],
  },
  'misconfigur|default password|weak cipher|ssl': {
    type: 'remediate',
    titleGen: (r, a) => `Remediate misconfiguration on ${a.name}`,
    titleArGen: (r, a) => `معالجة خطأ التكوين على ${a.name}`,
    descGen: (r, a) => `Apply security hardening configuration to ${a.name} based on CIS benchmarks`,
    descArGen: (r, a) => `تطبيق تكوين تقوية الأمان على ${a.name} بناءً على معايير CIS`,
    reasoningGen: (r, a) => `Misconfigurations are among the most common and easily exploitable vulnerabilities. Applying CIS benchmarks provides industry-standard hardening.`,
    reasoningArGen: (r, a) => `أخطاء التكوين من أكثر الثغرات شيوعاً وسهولة في الاستغلال. تطبيق معايير CIS يوفر تقوية بمعايير الصناعة.`,
    evidenceGen: (r, a) => [
      'CIS benchmark compliance verified for all applied settings',
      'Configuration changes tested in staging environment',
      'No service disruptions detected post-change',
      'Security headers and cipher suites verified',
      'Compliance scan shows improved score'
    ],
    evidenceArGen: (r, a) => [
      'تم التحقق من امتثال معايير CIS لجميع الإعدادات المطبقة',
      'تم اختبار تغييرات التكوين في بيئة التطوير',
      'لم يتم اكتشاف انقطاعات في الخدمة بعد التغيير',
      'تم التحقق من رؤوس الأمان ومجموعات التشفير',
      'فحص الامتثال يظهر درجة محسنة'
    ],
    testsGen: (r, a) => [
      { name: 'Configuration Compliance', nameAr: 'امتثال التكوين', details: 'All CIS benchmark checks passing', detailsAr: 'جميع فحوصات معايير CIS ناجحة' },
      { name: 'Service Functionality', nameAr: 'وظائف الخدمة', details: 'All services operating normally', detailsAr: 'جميع الخدمات تعمل بشكل طبيعي' },
      { name: 'Security Scan Re-check', nameAr: 'إعادة فحص الأمان', details: 'Previous misconfigurations no longer detected', detailsAr: 'أخطاء التكوين السابقة لم تعد مكتشفة' },
    ],
  },
  'port scan|nmap|scan': {
    type: 'monitor',
    titleGen: (r, a) => `Enhance monitoring and close unnecessary ports on ${a.name}`,
    titleArGen: (r, a) => `تعزيز المراقبة وإغلاق المنافذ غير الضرورية على ${a.name}`,
    descGen: (r, a) => `Close unused ports, implement port knocking, and enhance IDS/IPS rules for ${a.name}`,
    descArGen: (r, a) => `إغلاق المنافذ غير المستخدمة، تنفيذ port knocking، وتعزيز قواعد IDS/IPS لـ ${a.name}`,
    reasoningGen: (r, a) => `Port scanning indicates reconnaissance activity. Reducing attack surface by closing unused ports and enhancing monitoring provides defense-in-depth.`,
    reasoningArGen: (r, a) => `مسح المنافذ يشير إلى نشاط استطلاعي. تقليل سطح الهجوم بإغلاق المنافذ غير المستخدمة وتعزيز المراقبة يوفر دفاعاً متعدد الطبقات.`,
    evidenceGen: (r, a) => [
      'Port audit completed - only necessary ports remain open',
      'IDS rules updated to detect scan patterns',
      'Port knocking configured for administrative access',
      'Network segmentation verified for ${a.ip}',
      'Monitoring alerts configured for scan detection'
    ],
    evidenceArGen: (r, a) => [
      'اكتمل تدقيق المنافذ - فقط المنافذ الضرورية مفتوحة',
      'تم تحديث قواعد IDS لاكتشاف أنماط المسح',
      'تم تكوين Port knocking للوصول الإداري',
      'تم التحقق من تقسيم الشبكة لـ ${a.ip}',
      'تم تكوين تنبيهات المراقبة لاكتشاف المسح'
    ],
    testsGen: (r, a) => [
      { name: 'Port Audit', nameAr: 'تدقيق المنافذ', details: 'Only required ports accessible from network', detailsAr: 'فقط المنافذ المطلوبة قابلة للوصول من الشبكة' },
      { name: 'IDS Detection Test', nameAr: 'اختبار كشف IDS', details: 'IDS correctly detecting scan patterns', detailsAr: 'IDS يكتشف أنماط المسح بشكل صحيح' },
      { name: 'Service Availability', nameAr: 'توفر الخدمة', details: 'All required services still accessible', detailsAr: 'جميع الخدمات المطلوبة لا تزال قابلة للوصول' },
    ],
  },
};

/**
 * Find the best matching action template for a risk
 */
function findActionTemplate(risk: Risk): keyof typeof ACTION_TEMPLATES | null {
  const searchText = `${risk.title} ${risk.description} ${risk.cve || ''}`.toLowerCase();
  
  for (const [pattern] of Object.entries(ACTION_TEMPLATES)) {
    const regex = new RegExp(pattern, 'i');
    if (regex.test(searchText)) {
      return pattern as keyof typeof ACTION_TEMPLATES;
    }
  }
  
  // Default to generic remediation
  return 'misconfigur|default password|weak cipher|ssl';
}

/**
 * Calculate confidence score for an action
 */
function calculateConfidence(risk: Risk, asset: Asset): number {
  let confidence = 70; // Base confidence
  
  // Higher CVSS = more certain we need to act
  if (risk.cvssScore >= 9) confidence += 15;
  else if (risk.cvssScore >= 7) confidence += 10;
  else if (risk.cvssScore >= 4) confidence += 5;
  
  // Higher exploitability = more certain
  confidence += Math.min(risk.exploitability * 0.1, 10);
  
  // Critical assets get higher confidence for action
  if (asset.criticality === 'critical') confidence += 5;
  
  return Math.min(Math.round(confidence), 99);
}

/**
 * Calculate safety score for an action
 */
function calculateSafetyScore(action: AIAction['actionType'], asset: Asset): number {
  let safety = 80; // Base safety
  
  // Patches are generally safe
  if (action === 'patch') safety += 10;
  // Isolation is very safe (no service impact on other systems)
  if (action === 'isolate') safety += 15;
  // Monitoring is very safe
  if (action === 'monitor') safety += 12;
  // Blocking can have side effects
  if (action === 'block') safety -= 5;
  // Remediation varies
  if (action === 'remediate') safety += 5;
  
  // Critical assets need more caution
  if (asset.criticality === 'critical') safety -= 5;
  
  return Math.min(Math.max(Math.round(safety), 50), 99);
}

/**
 * Calculate optimal autonomy level for an action
 */
function calculateAutonomyLevel(risk: Risk, confidence: number, safety: number): number {
  const compositeScore = (confidence * 0.4 + safety * 0.3 + (100 - risk.exploitability) * 0.3) / 100;
  
  if (compositeScore > 0.9) return 5;
  if (compositeScore > 0.75) return 4;
  if (compositeScore > 0.6) return 3;
  if (compositeScore > 0.4) return 2;
  return 1;
}

/**
 * Generate AI action for a single risk
 */
export function generateActionForRisk(risk: Risk): AIAction | null {
  const asset = getAssetById(risk.assetId);
  if (!asset) return null;

  const templateKey = findActionTemplate(risk);
  if (!templateKey) return null;
  
  const template = ACTION_TEMPLATES[templateKey];
  const confidence = calculateConfidence(risk, asset);
  const safetyScore = calculateSafetyScore(template.type, asset);
  const autonomyLevel = calculateAutonomyLevel(risk, confidence, safetyScore);

  const action: Omit<AIAction, 'id' | 'createdAt'> = {
    riskId: risk.id,
    actionType: template.type,
    title: template.titleGen(risk, asset),
    titleAr: template.titleArGen(risk, asset),
    description: template.descGen(risk, asset),
    descriptionAr: template.descArGen(risk, asset),
    reasoning: template.reasoningGen(risk, asset),
    reasoningAr: template.reasoningArGen(risk, asset),
    confidence,
    safetyScore,
    estimatedTime: estimateTime(template.type),
    cost: estimateCost(template.type),
    successProbability: Math.round(confidence * 0.95 + safetyScore * 0.05),
    evidence: template.evidenceGen(risk, asset),
    evidenceAr: template.evidenceArGen(risk, asset),
    status: 'proposed',
    autonomyLevel,
  };

  return createAIAction(action);
}

/**
 * Run safety tests for an action in the sandbox
 */
export function runSafetyTests(actionId: string): TestResult[] {
  const allRisks = getAllRisks();
  
  // Get the action - import getAllActions at top
  const allActions = getAllActionsFn();
  const action = allActions.find((a: AIAction) => a.id === actionId);
  if (!action) return [];

  const risk = allRisks.find(r => r.id === action.riskId);
  const asset = risk ? getAssetById(risk.assetId) : null;
  if (!risk || !asset) return [];

  const templateKey = findActionTemplate(risk);
  const template = templateKey ? ACTION_TEMPLATES[templateKey] : null;
  if (!template) return [];

  const tests = template.testsGen(risk, asset);
  const results: TestResult[] = [];

  for (const test of tests) {
    // Simulate test execution with high pass rate
    const passed = Math.random() > 0.1; // 90% pass rate
    const duration = `${(Math.random() * 5 + 0.5).toFixed(1)}s`;
    
    const result = createTestResult({
      actionId,
      testName: test.name,
      testNameAr: test.nameAr,
      passed,
      duration,
      details: test.details,
      detailsAr: test.detailsAr,
    });
    
    results.push(result);
  }

  return results;
}

/**
 * Process all open risks and generate actions
 */
export function processAllRisks(): AIAction[] {
  const openRisks = getAllRisks().filter(r => r.status === 'open');
  const actions: AIAction[] = [];

  // Sort by priority (highest first)
  openRisks.sort((a, b) => b.priority - a.priority);

  for (const risk of openRisks) {
    // Check if we already have an action for this risk
    const existingActions = getActionsByRisk(risk.id);
    if (existingActions.length > 0) continue;

    const action = generateActionForRisk(risk);
    if (action) actions.push(action);
  }

  return actions;
}

// Helper functions
function estimateTime(type: AIAction['actionType']): string {
  switch (type) {
    case 'patch': return '15-30 min';
    case 'isolate': return '5-10 min';
    case 'block': return '5-15 min';
    case 'monitor': return '10-20 min';
    case 'remediate': return '20-60 min';
    case 'scan': return '30-120 min';
    default: return '30 min';
  }
}

function estimateCost(type: AIAction['actionType']): number {
  switch (type) {
    case 'patch': return 0;
    case 'isolate': return 0;
    case 'block': return 0;
    case 'monitor': return 50;
    case 'remediate': return 100;
    case 'scan': return 200;
    default: return 50;
  }
}
