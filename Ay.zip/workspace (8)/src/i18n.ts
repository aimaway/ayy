// Internationalization (i18n) system
export type Language = 'en' | 'ar' | 'fr';

export interface TranslationSet {
  // Navigation
  dashboard: string;
  assetDiscovery: string;
  riskAssessment: string;
  aiPredictor: string;
  safeTesting: string;
  reports: string;
  autonomyControl: string;
  liveLogs: string;
  settings: string;
  
  // Dashboard
  systemActive: string;
  autonomyLevel: string;
  assets: string;
  risks: string;
  aiDefenseAssistant: string;
  aiDefenseSubtitle: string;
  lastScan: string;
  trend: string;
  aiMode: string;
  discoveredAssets: string;
  criticalRisks: string;
  highRisks: string;
  actionsExecuted: string;
  aiConfidence: string;
  safetyScore: string;
  testsPassed: string;
  costSaved: string;
  latestAIPredictions: string;
  viewAll: string;
  riskPriorityQueue: string;
  processingPipeline: string;
  
  // Common
  active: string;
  vulnerable: string;
  inactive: string;
  critical: string;
  high: string;
  medium: string;
  low: string;
  verified: string;
  approved: string;
  testing: string;
  proposed: string;
  confidence: string;
  safety: string;
  priority: string;
  exploitability: string;
  businessImpact: string;
  
  // Settings
  language: string;
  english: string;
  arabic: string;
  french: string;
  theme: string;
  darkMode: string;
  notifications: string;
  scanScope: string;
  save: string;
  cancel: string;
}

const en: TranslationSet = {
  dashboard: 'Dashboard',
  assetDiscovery: 'Asset Discovery',
  riskAssessment: 'Risk Assessment',
  aiPredictor: 'AI Predictor',
  safeTesting: 'Safe Testing',
  reports: 'Reports',
  autonomyControl: 'Autonomy Control',
  liveLogs: 'Live Logs',
  settings: 'Settings',
  
  systemActive: 'System Active',
  autonomyLevel: 'Autonomy Level',
  assets: 'Assets',
  risks: 'Risks',
  aiDefenseAssistant: 'AI Cyber Defense Assistant',
  aiDefenseSubtitle: 'Predicts optimal security actions, proves safety & success',
  lastScan: 'Last Scan',
  trend: 'Trend',
  aiMode: 'AI Mode',
  discoveredAssets: 'Discovered Assets',
  criticalRisks: 'Critical Risks',
  highRisks: 'High Risks',
  actionsExecuted: 'Actions Executed',
  aiConfidence: 'AI Confidence',
  safetyScore: 'Safety Score',
  testsPassed: 'Tests Passed',
  costSaved: 'Cost Saved',
  latestAIPredictions: 'Latest AI Predictions',
  viewAll: 'View All →',
  riskPriorityQueue: 'Risk Priority Queue',
  processingPipeline: 'Processing Pipeline',
  
  active: 'Active',
  vulnerable: 'Vulnerable',
  inactive: 'Inactive',
  critical: 'Critical',
  high: 'High',
  medium: 'Medium',
  low: 'Low',
  verified: 'Verified',
  approved: 'Approved',
  testing: 'Testing',
  proposed: 'Proposed',
  confidence: 'Confidence',
  safety: 'Safety',
  priority: 'Priority',
  exploitability: 'Exploitability',
  businessImpact: 'Business Impact',
  
  language: 'Language',
  english: 'English',
  arabic: 'العربية',
  french: 'Français',
  theme: 'Theme',
  darkMode: 'Dark Mode',
  notifications: 'Notifications',
  scanScope: 'Scan Scope',
  save: 'Save',
  cancel: 'Cancel',
};

const ar: TranslationSet = {
  dashboard: 'لوحة التحكم',
  assetDiscovery: 'اكتشاف الأصول',
  riskAssessment: 'تقييم المخاطر',
  aiPredictor: 'تنبؤ الذكاء الاصطناعي',
  safeTesting: 'الاختبار الآمن',
  reports: 'التقارير',
  autonomyControl: 'التحكم بالاستقلالية',
  liveLogs: 'السجلات الحية',
  settings: 'الإعدادات',
  
  systemActive: 'النظام نشط',
  autonomyLevel: 'مستوى الاستقلالية',
  assets: 'أصول',
  risks: 'مخاطر',
  aiDefenseAssistant: 'مساعد الدفاع السيبراني الذكي',
  aiDefenseSubtitle: 'يتنبأ بأفضل إجراء أمني، يثبت أمانه ونجاحه',
  lastScan: 'آخر فحص',
  trend: 'الاتجاه',
  aiMode: 'وضع الذكاء الاصطناعي',
  discoveredAssets: 'الأصول المكتشفة',
  criticalRisks: 'المخاطر الحرجة',
  highRisks: 'المخاطر العالية',
  actionsExecuted: 'الإجراءات المنفذة',
  aiConfidence: 'ثقة الذكاء الاصطناعي',
  safetyScore: 'درجة الأمان',
  testsPassed: 'الاختبارات الناجحة',
  costSaved: 'التكلفة الموفرة',
  latestAIPredictions: 'آخر تنبؤات الذكاء الاصطناعي',
  viewAll: '← عرض الكل',
  riskPriorityQueue: 'طابور أولويات المخاطر',
  processingPipeline: 'خط أنابيب المعالجة',
  
  active: 'نشط',
  vulnerable: 'معرض للخطر',
  inactive: 'غير نشط',
  critical: 'حرج',
  high: 'عالي',
  medium: 'متوسط',
  low: 'منخفض',
  verified: 'تم التحقق',
  approved: 'موافق عليه',
  testing: 'قيد الاختبار',
  proposed: 'مقترح',
  confidence: 'الثقة',
  safety: 'الأمان',
  priority: 'الأولوية',
  exploitability: 'الاستغلالية',
  businessImpact: 'الأثر على الأعمال',
  
  language: 'اللغة',
  english: 'English',
  arabic: 'العربية',
  french: 'Français',
  theme: 'المظهر',
  darkMode: 'الوضع الداكن',
  notifications: 'الإشعارات',
  scanScope: 'نطاق الفحص',
  save: 'حفظ',
  cancel: 'إلغاء',
};

const fr: TranslationSet = {
  dashboard: 'Tableau de bord',
  assetDiscovery: 'Découverte des actifs',
  riskAssessment: 'Évaluation des risques',
  aiPredictor: 'Prédicteur IA',
  safeTesting: 'Tests sécurisés',
  reports: 'Rapports',
  autonomyControl: "Contrôle d'autonomie",
  liveLogs: 'Journaux en direct',
  settings: 'Paramètres',
  
  systemActive: 'Système actif',
  autonomyLevel: "Niveau d'autonomie",
  assets: 'Actifs',
  risks: 'Risques',
  aiDefenseAssistant: 'Assistant IA de Cybersécurité',
  aiDefenseSubtitle: "Prédit les actions de sécurité optimales, prouve la sécurité et le succès",
  lastScan: 'Dernier scan',
  trend: 'Tendance',
  aiMode: 'Mode IA',
  discoveredAssets: 'Actifs découverts',
  criticalRisks: 'Risques critiques',
  highRisks: 'Risques élevés',
  actionsExecuted: 'Actions exécutées',
  aiConfidence: "Confiance de l'IA",
  safetyScore: 'Score de sécurité',
  testsPassed: 'Tests réussis',
  costSaved: 'Coûts économisés',
  latestAIPredictions: 'Dernières prédictions IA',
  viewAll: '← Voir tout',
  riskPriorityQueue: 'File de priorité des risques',
  processingPipeline: 'Pipeline de traitement',
  
  active: 'Actif',
  vulnerable: 'Vulnérable',
  inactive: 'Inactif',
  critical: 'Critique',
  high: 'Élevé',
  medium: 'Moyen',
  low: 'Faible',
  verified: 'Vérifié',
  approved: 'Approuvé',
  testing: 'En test',
  proposed: 'Proposé',
  confidence: 'Confiance',
  safety: 'Sécurité',
  priority: 'Priorité',
  exploitability: 'Exploitabilité',
  businessImpact: 'Impact métier',
  
  language: 'Langue',
  english: 'English',
  arabic: 'العربية',
  french: 'Français',
  theme: 'Thème',
  darkMode: 'Mode sombre',
  notifications: 'Notifications',
  scanScope: 'Portée du scan',
  save: 'Enregistrer',
  cancel: 'Annuler',
};

const translations: Record<Language, TranslationSet> = { en, ar, fr };

export function getTranslations(lang: Language): TranslationSet {
  return translations[lang];
}

export function isRTL(lang: Language): boolean {
  return lang === 'ar';
}
