/**
 * CyberShield AI - API Service
 * Connects the frontend to the real backend
 * Falls back to mock data if backend is unavailable
 */

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';
const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:3001/ws';

// ============ HTTP API ============

async function fetchApi<T>(endpoint: string, options?: RequestInit): Promise<T> {
  try {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      headers: { 'Content-Type': 'application/json' },
      ...options,
    });
    
    if (!response.ok) {
      throw new Error(`API Error: ${response.status} ${response.statusText}`);
    }
    
    return response.json();
  } catch (error) {
    console.warn(`[API] Failed to fetch ${endpoint}:`, error);
    throw error;
  }
}

// Dashboard
export const api = {
  // Dashboard
  getDashboardStats: () => fetchApi<any>('/dashboard/stats'),
  
  // Assets
  getAssets: () => fetchApi<any>('/assets'),
  getAsset: (id: string) => fetchApi<any>(`/assets/${id}`),
  createAsset: (data: any) => fetchApi<any>('/assets', { method: 'POST', body: JSON.stringify(data) }),
  updateAsset: (id: string, data: any) => fetchApi<any>(`/assets/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  
  // Risks
  getRisks: (params?: { severity?: string; assetId?: string }) => {
    const query = new URLSearchParams(params as any).toString();
    return fetchApi<any>(`/risks${query ? '?' + query : ''}`);
  },
  updateRiskStatus: (id: string, status: string) => 
    fetchApi<any>(`/risks/${id}/status`, { method: 'PUT', body: JSON.stringify({ status }) }),
  
  // AI Actions
  getActions: () => fetchApi<any>('/actions'),
  getActionsByRisk: (riskId: string) => fetchApi<any>(`/actions/risk/${riskId}`),
  updateActionStatus: (id: string, status: string) => 
    fetchApi<any>(`/actions/${id}/status`, { method: 'PUT', body: JSON.stringify({ status }) }),
  
  // AI Processing
  processRisks: () => fetchApi<any>('/ai/process-risks', { method: 'POST' }),
  generateAction: (riskId: string) => fetchApi<any>(`/ai/generate-action/${riskId}`, { method: 'POST' }),
  
  // Safe Testing
  runTests: (actionId: string) => fetchApi<any>(`/testing/run/${actionId}`, { method: 'POST' }),
  getTestResults: (actionId: string) => fetchApi<any>(`/testing/results/${actionId}`),
  
  // Logs
  getLogs: (params?: { severity?: string; assetId?: string; limit?: number }) => {
    const query = new URLSearchParams(params as any).toString();
    return fetchApi<any>(`/logs${query ? '?' + query : ''}`);
  },
  ingestLogs: (logs: string[], source?: string) => 
    fetchApi<any>('/logs', { method: 'POST', body: JSON.stringify({ logs, source }) }),
  ingestSingleLog: (rawLog: string, source?: string) => 
    fetchApi<any>('/logs', { method: 'POST', body: JSON.stringify({ rawLog, source }) }),
  
  // Config
  getConfig: () => fetchApi<any>('/config'),
  updateAutonomyLevel: (level: number) => 
    fetchApi<any>('/config/autonomy', { method: 'PUT', body: JSON.stringify({ level }) }),
  updateScope: (scope: string) => 
    fetchApi<any>('/config/scope', { method: 'PUT', body: JSON.stringify({ scope }) }),
  
  // Health
  healthCheck: () => fetchApi<any>('/health'),
};

// ============ WEBSOCKET ============

export type WSEventType = 'log' | 'asset_update' | 'risk_alert' | 'action_update' | 'scan_progress' | 'system_status';

export interface WSEvent {
  type: WSEventType;
  payload: any;
  timestamp: string;
}

type WSEventHandler = (event: WSEvent) => void;

class CyberShieldWebSocket {
  private ws: WebSocket | null = null;
  private handlers: Map<WSEventType, Set<WSEventHandler>> = new Map();
  private reconnectTimeout: NodeJS.Timeout | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 10;
  private reconnectDelay = 3000;

  connect(): void {
    if (this.ws?.readyState === WebSocket.OPEN) return;

    try {
      this.ws = new WebSocket(WS_URL);

      this.ws.onopen = () => {
        console.log('[WS] Connected to CyberShield AI backend');
        this.reconnectAttempts = 0;
      };

      this.ws.onmessage = (event) => {
        try {
          const data: WSEvent = JSON.parse(event.data);
          this.notifyHandlers(data);
        } catch (err) {
          console.error('[WS] Failed to parse message:', err);
        }
      };

      this.ws.onclose = () => {
        console.log('[WS] Disconnected from backend');
        this.scheduleReconnect();
      };

      this.ws.onerror = (err) => {
        console.error('[WS] Connection error:', err);
      };
    } catch (err) {
      console.error('[WS] Failed to connect:', err);
      this.scheduleReconnect();
    }
  }

  disconnect(): void {
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
    }
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  send(message: any): void {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    }
  }

  sendLog(rawLog: string): void {
    this.send({ type: 'log', payload: rawLog });
  }

  sendBatchLogs(logs: string[]): void {
    this.send({ type: 'batch_logs', payload: logs });
  }

  triggerAIScan(): void {
    this.send({ type: 'trigger_scan' });
  }

  on(type: WSEventType, handler: WSEventHandler): () => void {
    if (!this.handlers.has(type)) {
      this.handlers.set(type, new Set());
    }
    this.handlers.get(type)!.add(handler);

    // Return unsubscribe function
    return () => {
      this.handlers.get(type)?.delete(handler);
    };
  }

  onAny(handler: WSEventHandler): () => void {
    const types: WSEventType[] = ['log', 'asset_update', 'risk_alert', 'action_update', 'scan_progress', 'system_status'];
    const unsubscribes = types.map(type => this.on(type, handler));
    return () => unsubscribes.forEach(unsub => unsub());
  }

  private notifyHandlers(event: WSEvent): void {
    const handlers = this.handlers.get(event.type);
    if (handlers) {
      handlers.forEach(handler => handler(event));
    }
  }

  private scheduleReconnect(): void {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.warn('[WS] Max reconnect attempts reached. Backend may be offline.');
      return;
    }

    this.reconnectAttempts++;
    const delay = this.reconnectDelay * Math.pow(1.5, this.reconnectAttempts - 1);
    
    console.log(`[WS] Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts})...`);
    
    this.reconnectTimeout = setTimeout(() => {
      this.connect();
    }, delay);
  }

  isConnected(): boolean {
    return this.ws?.readyState === WebSocket.OPEN;
  }
}

export const wsClient = new CyberShieldWebSocket();

// ============ CONNECTION STATUS ============

export interface ConnectionStatus {
  api: 'connected' | 'disconnected' | 'checking';
  websocket: 'connected' | 'disconnected' | 'connecting';
  lastCheck: string;
}

export async function checkConnection(): Promise<ConnectionStatus> {
  let apiStatus: 'connected' | 'disconnected' = 'disconnected';
  
  try {
    await api.healthCheck();
    apiStatus = 'connected';
  } catch {
    apiStatus = 'disconnected';
  }

  return {
    api: apiStatus,
    websocket: wsClient.isConnected() ? 'connected' : 'disconnected',
    lastCheck: new Date().toISOString(),
  };
}
