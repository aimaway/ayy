import { useState, createContext, useContext } from 'react';
import { 
  Shield, Activity, Database, AlertTriangle, Brain, 
  FileText, Settings, ChevronLeft, Zap, Eye, Terminal,
  Globe
} from 'lucide-react';
import Dashboard from './components/Dashboard';
import AssetDiscovery from './components/AssetDiscovery';
import RiskAssessment from './components/RiskAssessment';
import AIPredictor from './components/AIPredictor';
import SafeTesting from './components/SafeTesting';
import Reports from './components/Reports';
import AutonomyControl from './components/AutonomyControl';
import LiveLogs from './components/LiveLogs';
import AppSettings from './components/AppSettings';
import { getTranslations, isRTL, type Language } from './i18n';

type TabType = 'dashboard' | 'assets' | 'risks' | 'predictor' | 'testing' | 'reports' | 'autonomy' | 'logs' | 'settings';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: ReturnType<typeof getTranslations>;
  rtl: boolean;
}

export const AppContext = createContext<AppContextType>({
  language: 'en',
  setLanguage: () => {},
  t: getTranslations('en'),
  rtl: false,
});

export const useApp = () => useContext(AppContext);

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [language, setLanguage] = useState<Language>('en');
  
  const t = getTranslations(language);
  const rtl = isRTL(language);

  const tabs: { id: TabType; label: string; icon: React.ComponentType<{className?: string}> }[] = [
    { id: 'dashboard', label: t.dashboard, icon: Activity },
    { id: 'assets', label: t.assetDiscovery, icon: Database },
    { id: 'risks', label: t.riskAssessment, icon: AlertTriangle },
    { id: 'predictor', label: t.aiPredictor, icon: Brain },
    { id: 'testing', label: t.safeTesting, icon: Shield },
    { id: 'reports', label: t.reports, icon: FileText },
    { id: 'autonomy', label: t.autonomyControl, icon: Settings },
    { id: 'logs', label: t.liveLogs, icon: Terminal },
    { id: 'settings', label: t.settings, icon: Globe },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard onNavigate={(tab) => setActiveTab(tab as TabType)} />;
      case 'assets': return <AssetDiscovery />;
      case 'risks': return <RiskAssessment />;
      case 'predictor': return <AIPredictor />;
      case 'testing': return <SafeTesting />;
      case 'reports': return <Reports />;
      case 'autonomy': return <AutonomyControl />;
      case 'logs': return <LiveLogs />;
      case 'settings': return <AppSettings />;
      default: return <Dashboard onNavigate={(tab) => setActiveTab(tab as TabType)} />;
    }
  };

  return (
    <AppContext.Provider value={{ language, setLanguage, t, rtl }}>
      <div className={`flex h-screen bg-mesh bg-grid bg-noise ${rtl ? 'flex-row-reverse' : ''}`} dir={rtl ? 'rtl' : 'ltr'}>
        {/* Sidebar */}
        <aside className={`${sidebarCollapsed ? 'w-[72px]' : 'w-64'} transition-all duration-300 bg-[var(--bg-secondary)] border-r border-[var(--border-subtle)] flex flex-col relative`}>
          {/* Logo */}
          <div className="p-4 border-b border-[var(--border-subtle)] flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[var(--accent-cyan)] to-[var(--accent-purple)] flex items-center justify-center flex-shrink-0 shadow-lg shadow-cyan-500/20">
              <Shield className="w-5 h-5 text-white" />
            </div>
            {!sidebarCollapsed && (
              <div className="animate-fade-in overflow-hidden">
                <h1 className="text-sm font-bold text-white tracking-tight">CyberShield AI</h1>
                <p className="text-[10px] text-[var(--accent-cyan)] font-medium">Defense Platform</p>
              </div>
            )}
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 text-sm group relative
                    ${isActive 
                      ? 'bg-gradient-to-r from-cyan-500/10 to-purple-500/10 text-white border border-cyan-500/20' 
                      : 'text-slate-400 hover:bg-white/5 hover:text-white'
                    }`}
                >
                  {isActive && (
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-gradient-to-b from-cyan-400 to-purple-400 rounded-r-full" />
                  )}
                  <Icon className={`w-5 h-5 flex-shrink-0 transition-colors ${isActive ? 'text-cyan-400' : 'group-hover:text-cyan-400'}`} />
                  {!sidebarCollapsed && <span className="font-medium">{tab.label}</span>}
                </button>
              );
            })}
          </nav>

          {/* Collapse button */}
          <div className="p-3 border-t border-[var(--border-subtle)]">
            <button
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-slate-500 hover:bg-white/5 hover:text-white transition-colors"
            >
              <ChevronLeft className={`w-4 h-4 transition-transform duration-300 ${sidebarCollapsed ? 'rotate-180' : ''}`} />
              {!sidebarCollapsed && <span className="text-xs font-medium">Collapse</span>}
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto relative">
          {/* Top Bar */}
          <header className="sticky top-0 z-20 bg-[var(--bg-primary)]/80 backdrop-blur-xl border-b border-[var(--border-subtle)] px-6 py-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <h2 className="text-lg font-bold text-white tracking-tight">
                  {tabs.find(t => t.id === activeTab)?.label}
                </h2>
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-xs text-emerald-400 font-medium">{t.systemActive}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-purple-500/10 border border-purple-500/20">
                  <Zap className="w-3.5 h-3.5 text-purple-400" />
                  <span className="text-xs text-purple-300 font-medium">{t.autonomyLevel}: 3</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20">
                  <Eye className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="text-xs text-cyan-300 font-medium">6 {t.assets}</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-rose-500/10 border border-rose-500/20">
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                  <span className="text-xs text-rose-300 font-medium">6 {t.risks}</span>
                </div>
              </div>
            </div>
          </header>

          {/* Content Area */}
          <div className="p-6 max-w-[1600px] mx-auto">
            {renderContent()}
          </div>
        </main>
      </div>
    </AppContext.Provider>
  );
}

export default App;
