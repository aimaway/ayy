import { useState } from 'react';
import { AlertTriangle, TrendingUp, Filter, ArrowUpDown } from 'lucide-react';
import { mockRisks, mockAssets } from '../data';
import { useApp } from '../App';

export default function RiskAssessment() {
  const { t } = useApp();
  const [sortBy, setSortBy] = useState<'priority' | 'cvss' | 'exploitability'>('priority');
  const [filterSeverity, setFilterSeverity] = useState<string>('all');

  const filteredRisks = mockRisks
    .filter(r => filterSeverity === 'all' || r.severity === filterSeverity)
    .sort((a, b) => {
      if (sortBy === 'priority') return b.priority - a.priority;
      if (sortBy === 'cvss') return b.cvssScore - a.cvssScore;
      return b.exploitability - a.exploitability;
    });

  const getAssetName = (assetId: string) => mockAssets.find(a => a.id === assetId)?.name || 'Unknown';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h3 className="text-2xl font-bold text-white">Risk Assessment & Priority Ranking</h3>
          <p className="text-slate-400 mt-1">Analyze discovered risks with AI-powered priority explanation</p>
        </div>
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400" />
          {['all', 'critical', 'high', 'medium', 'low'].map((sev) => (
            <button
              key={sev}
              onClick={() => setFilterSeverity(sev)}
              className={`text-xs px-3 py-1.5 rounded-lg transition-all font-medium ${
                filterSeverity === sev 
                  ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30' 
                  : 'bg-slate-800/50 text-slate-400 hover:text-white'
              }`}
            >
              {sev === 'all' ? 'All' : sev.charAt(0).toUpperCase() + sev.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-2">
        <ArrowUpDown className="w-4 h-4 text-slate-400" />
        <span className="text-xs text-slate-400">Sort by:</span>
        {[
          { key: 'priority', label: 'Priority' },
          { key: 'cvss', label: 'CVSS' },
          { key: 'exploitability', label: 'Exploitability' },
        ].map((sort) => (
          <button
            key={sort.key}
            onClick={() => setSortBy(sort.key as any)}
            className={`text-xs px-3 py-1 rounded-lg transition-all font-medium ${
              sortBy === sort.key ? 'bg-purple-500/20 text-purple-400' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            {sort.label}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        {filteredRisks.map((risk, index) => (
          <div
            key={risk.id}
            className="glass-card p-5 border-l-4 animate-slide-in-right"
            style={{ 
              animationDelay: `${index * 0.1}s`,
              borderLeftColor: risk.severity === 'critical' ? '#f43f5e' : risk.severity === 'high' ? '#f59e0b' : '#eab308'
            }}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  risk.severity === 'critical' ? 'bg-rose-500/20' :
                  risk.severity === 'high' ? 'bg-amber-500/20' :
                  'bg-yellow-500/20'
                }`}>
                  <span className={`text-lg font-bold ${
                    risk.severity === 'critical' ? 'text-rose-400' :
                    risk.severity === 'high' ? 'text-amber-400' :
                    'text-yellow-400'
                  }`}>
                    {risk.cvssScore}
                  </span>
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">{risk.title}</h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Asset: <span className="text-cyan-400">{getAssetName(risk.assetId)}</span>
                    {risk.cve && <span className="ml-2 text-purple-400">({risk.cve})</span>}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-[10px] px-2 py-1 rounded-lg font-semibold ${
                  risk.severity === 'critical' ? 'bg-rose-500/10 text-rose-400' :
                  risk.severity === 'high' ? 'bg-amber-500/10 text-amber-400' :
                  'bg-yellow-500/10 text-yellow-400'
                }`}>
                  {risk.severity.toUpperCase()}
                </span>
                <span className="text-[10px] px-2 py-1 rounded-lg bg-purple-500/10 text-purple-400 font-semibold">
                  Priority: {risk.priority}
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-300 mb-4">{risk.description}</p>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] text-slate-500 font-medium">Exploitability</span>
                  <span className="text-[10px] text-white font-semibold">{risk.exploitability}%</span>
                </div>
                <div className="progress-bar">
                  <div className="progress-fill bg-gradient-to-r from-rose-500 to-orange-500" style={{ width: `${risk.exploitability}%` }} />
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] text-slate-500 font-medium">Business Impact</span>
                  <span className="text-[10px] text-white font-semibold">{risk.businessImpact}%</span>
                </div>
                <div className="progress-bar">
                  <div className="progress-fill bg-gradient-to-r from-purple-500 to-pink-500" style={{ width: `${risk.businessImpact}%` }} />
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] text-slate-500 font-medium">Calculated Priority</span>
                  <span className="text-[10px] text-white font-semibold">{risk.priority}%</span>
                </div>
                <div className="progress-bar">
                  <div className="progress-fill bg-gradient-to-r from-cyan-500 to-blue-500" style={{ width: `${risk.priority}%` }} />
                </div>
              </div>
            </div>

            <div className="mt-4 p-3 rounded-xl bg-purple-500/5 border border-purple-500/20">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-3 h-3 text-purple-400" />
                <span className="text-[10px] text-purple-400 font-bold uppercase tracking-wide">AI Priority Reasoning</span>
              </div>
              <p className="text-xs text-slate-300">
                {risk.severity === 'critical' 
                  ? `This risk is ranked as top priority (${risk.priority}/100) due to the combination of high CVSS score (${risk.cvssScore}), high exploitability (${risk.exploitability}%), and significant business impact (${risk.businessImpact}%). Requires immediate action.`
                  : risk.severity === 'high'
                  ? `High priority risk (${risk.priority}/100) due to ${risk.exploitability > 80 ? 'easy' : 'moderate'} exploitability and notable business impact. Recommended remediation within 48 hours.`
                  : `Medium priority risk (${risk.priority}/100) requiring planned remediation. No immediate threat but increases attack surface.`
                }
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
