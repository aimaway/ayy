import { useState } from 'react';
import { Database, Server, Cloud, Monitor, Globe, HardDrive, RefreshCw } from 'lucide-react';
import { mockAssets, type Asset } from '../data';
import { useApp } from '../App';

export default function AssetDiscovery() {
  const { t } = useApp();
  const [scanning, setScanning] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);

  const getIcon = (type: string) => {
    switch (type) {
      case 'server': return Server;
      case 'database': return HardDrive;
      case 'endpoint': return Monitor;
      case 'network': return Globe;
      case 'application': return Globe;
      case 'cloud': return Cloud;
      default: return Database;
    }
  };

  const handleScan = () => {
    setScanning(true);
    setTimeout(() => setScanning(false), 3000);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-2xl font-bold text-white">Discover Assets in Authorized Scope</h3>
          <p className="text-slate-400 mt-1">Scan range: 10.0.0.0/16 | Last scan: January 15, 2026</p>
        </div>
        <button
          onClick={handleScan}
          disabled={scanning}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold transition-all ${
            scanning 
              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' 
              : 'btn-primary'
          }`}
        >
          <RefreshCw className={`w-4 h-4 ${scanning ? 'animate-spin' : ''}`} />
          {scanning ? 'Scanning...' : 'Start New Scan'}
        </button>
      </div>

      {scanning && (
        <div className="glass-card p-6">
          <div className="terminal space-y-1">
            <p className="terminal-info">[INFO] Starting asset discovery in range 10.0.0.0/16...</p>
            <p className="terminal-success">[SCAN] Scanning open ports...</p>
            <p className="terminal-success">[SCAN] Identifying active services...</p>
            <p className="terminal-warning">[DISCOVER] Found 6 new assets...</p>
            <p className="terminal-info">[INFO] Classifying assets by criticality...</p>
            <p className="animate-pulse text-white">█</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="metric-card">
          <p className="metric-value">{mockAssets.length}</p>
          <p className="metric-label">Total Assets</p>
        </div>
        <div className="metric-card">
          <p className="metric-value text-rose-400">{mockAssets.filter(a => a.status === 'vulnerable').length}</p>
          <p className="metric-label">Vulnerable</p>
        </div>
        <div className="metric-card">
          <p className="metric-value text-emerald-400">{mockAssets.filter(a => a.status === 'active').length}</p>
          <p className="metric-label">Active</p>
        </div>
        <div className="metric-card">
          <p className="metric-value text-purple-400">{mockAssets.filter(a => a.criticality === 'critical').length}</p>
          <p className="metric-label">Critical</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {mockAssets.map((asset) => {
          const Icon = getIcon(asset.type);
          return (
            <div
              key={asset.id}
              onClick={() => setSelectedAsset(selectedAsset?.id === asset.id ? null : asset)}
              className={`glass-card p-5 cursor-pointer transition-all duration-200 hover:scale-[1.02] ${
                selectedAsset?.id === asset.id ? 'border-cyan-500/50 shadow-lg shadow-cyan-500/10' : ''
              }`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${
                    asset.status === 'vulnerable' ? 'bg-rose-500/10' : 'bg-cyan-500/10'
                  }`}>
                    <Icon className={`w-5 h-5 ${asset.status === 'vulnerable' ? 'text-rose-400' : 'text-cyan-400'}`} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-white">{asset.name}</p>
                    <p className="text-[10px] text-slate-500 font-mono">{asset.ip}</p>
                  </div>
                </div>
                <span className={`text-[10px] px-2 py-1 rounded-lg font-semibold ${
                  asset.status === 'active' ? 'bg-emerald-500/10 text-emerald-400' :
                  asset.status === 'vulnerable' ? 'bg-rose-500/10 text-rose-400' :
                  'bg-slate-500/10 text-slate-400'
                }`}>
                  {asset.status === 'active' ? 'Active' : asset.status === 'vulnerable' ? 'Vulnerable' : 'Inactive'}
                </span>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">Criticality:</span>
                  <span className={`text-[10px] px-2 py-1 rounded-lg font-semibold ${
                    asset.criticality === 'critical' ? 'bg-rose-500/20 text-rose-400' :
                    asset.criticality === 'high' ? 'bg-amber-500/20 text-amber-400' :
                    asset.criticality === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-emerald-500/20 text-emerald-400'
                  }`}>
                    {asset.criticality.charAt(0).toUpperCase() + asset.criticality.slice(1)}
                  </span>
                </div>
                {asset.os && (
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-400">OS:</span>
                    <span className="text-xs text-slate-300">{asset.os}</span>
                  </div>
                )}
                {asset.openPorts && (
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-400">Ports:</span>
                    <span className="text-xs text-slate-300 font-mono">{asset.openPorts.join(', ')}</span>
                  </div>
                )}
                {asset.services && (
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {asset.services.map((service) => (
                      <span key={service} className="text-[10px] px-2 py-1 rounded-lg bg-slate-800/50 text-slate-400 font-medium border border-slate-700/50">
                        {service}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
