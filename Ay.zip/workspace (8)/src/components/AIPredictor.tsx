import { useState } from 'react';
import { Brain, CheckCircle, Shield, Clock, Zap, ChevronDown, ChevronUp, Lightbulb, Lock, Target } from 'lucide-react';
import { mockActions, mockRisks } from '../data';

export default function AIPredictor() {
  const [expandedAction, setExpandedAction] = useState<string | null>(null);
  const [isThinking, setIsThinking] = useState(false);
  const [currentPrediction, setCurrentPrediction] = useState(0);

  const simulatePrediction = () => {
    setIsThinking(true);
    setCurrentPrediction(0);
    const interval = setInterval(() => {
      setCurrentPrediction(prev => {
        if (prev >= mockActions.length) {
          clearInterval(interval);
          setIsThinking(false);
          return mockActions.length;
        }
        return prev + 1;
      });
    }, 800);
  };

  const getRiskTitle = (riskId: string) => mockRisks.find(r => r.id === riskId)?.title || '';
  const visibleActions = isThinking ? mockActions.slice(0, currentPrediction) : mockActions;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h3 className="text-2xl font-bold text-white flex items-center gap-2">
            <Brain className="w-6 h-6 text-purple-400" />
            AI Security Action Predictor
          </h3>
          <p className="text-slate-400 mt-1">Predicts optimal security actions with reasoning and safety proof</p>
        </div>
        <button onClick={simulatePrediction} disabled={isThinking} className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold transition-all ${isThinking ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30 animate-pulse' : 'btn-primary'}`}>
          <Zap className="w-4 h-4" />
          {isThinking ? 'Analyzing...' : 'Run Prediction'}
        </button>
      </div>

      {isThinking && (
        <div className="glass-card p-5 border-purple-500/30">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center">
              <Brain className="w-5 h-5 text-purple-400 animate-pulse" />
            </div>
            <div>
              <p className="text-sm text-purple-300 font-bold">AI is analyzing...</p>
              <p className="text-xs text-slate-400">Evaluating risks and determining optimal next actions</p>
            </div>
          </div>
          <div className="terminal space-y-1">
            <p className="terminal-info">→ Analyzing {mockRisks.length} discovered risks...</p>
            <p className="terminal-success">→ Assessing exploitability for each risk...</p>
            <p className="terminal-warning">→ Calculating remediation priority...</p>
            <p className="terminal-info">→ Generating proposed actions...</p>
            <p className="terminal-success">→ Verifying safety of each action...</p>
            <p className="terminal-success">→ Proving action success in safe environment...</p>
          </div>
        </div>
      )}

      <div className="space-y-4">
        {visibleActions.map((action, index) => {
          const isExpanded = expandedAction === action.id;
          return (
            <div key={action.id} className="glass-card overflow-hidden animate-fade-in-up" style={{ animationDelay: `${index * 0.15}s` }}>
              <div className="p-5 cursor-pointer hover:bg-white/5 transition-colors" onClick={() => setExpandedAction(isExpanded ? null : action.id)}>
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <div className="flex flex-col items-center">
                      <span className="text-2xl">{action.actionType === 'patch' ? '🔧' : action.actionType === 'block' ? '🚫' : '🛠️'}</span>
                      <span className="text-[10px] text-slate-500 mt-1 font-mono">#{index + 1}</span>
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">{action.title}</h4>
                      <p className="text-xs text-slate-400 mt-1">For risk: <span className="text-rose-400">{getRiskTitle(action.riskId)}</span></p>
                      <div className="flex items-center gap-3 mt-2">
                        <span className={`text-[10px] px-2 py-1 rounded-lg font-semibold ${action.status === 'verified' ? 'bg-emerald-500/10 text-emerald-400' : action.status === 'approved' ? 'bg-blue-500/10 text-blue-400' : action.status === 'testing' ? 'bg-amber-500/10 text-amber-400' : 'bg-slate-500/10 text-slate-400'}`}>
                          {action.status.charAt(0).toUpperCase() + action.status.slice(1)}
                        </span>
                        <span className="text-[10px] text-slate-500 flex items-center gap-1"><Clock className="w-3 h-3" /> {action.estimatedTime}</span>
                        <span className="text-[10px] text-slate-500">Autonomy: L{action.autonomyLevel}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-center">
                      <div className="relative w-14 h-14">
                        <svg className="w-14 h-14 -rotate-90" viewBox="0 0 36 36">
                          <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#1e293b" strokeWidth="3" />
                          <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#00f0ff" strokeWidth="3" strokeDasharray={`${action.confidence}, 100`} />
                        </svg>
                        <span className="absolute inset-0 flex items-center justify-center text-xs text-cyan-400 font-bold">{action.confidence}%</span>
                      </div>
                      <span className="text-[9px] text-slate-500 font-medium">Confidence</span>
                    </div>
                    <div className="text-center">
                      <div className="relative w-14 h-14">
                        <svg className="w-14 h-14 -rotate-90" viewBox="0 0 36 36">
                          <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#1e293b" strokeWidth="3" />
                          <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#10b981" strokeWidth="3" strokeDasharray={`${action.safetyScore}, 100`} />
                        </svg>
                        <span className="absolute inset-0 flex items-center justify-center text-xs text-emerald-400 font-bold">{action.safetyScore}%</span>
                      </div>
                      <span className="text-[9px] text-slate-500 font-medium">Safety</span>
                    </div>
                    {isExpanded ? <ChevronUp className="w-5 h-5 text-slate-400" /> : <ChevronDown className="w-5 h-5 text-slate-400" />}
                  </div>
                </div>
              </div>

              {isExpanded && (
                <div className="px-5 pb-5 border-t border-slate-800/50 pt-5 space-y-4 animate-fade-in-up">
                  <div className="p-4 rounded-xl bg-black/30 border border-slate-700/50">
                    <p className="text-xs text-slate-300">{action.description}</p>
                  </div>
                  <div className="p-4 rounded-xl bg-purple-500/5 border border-purple-500/20">
                    <div className="flex items-center gap-2 mb-2">
                      <Lightbulb className="w-4 h-4 text-purple-400" />
                      <span className="text-xs text-purple-400 font-bold">Why this action was chosen</span>
                    </div>
                    <p className="text-xs text-slate-300">{action.reasoning}</p>
                  </div>
                  <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
                    <div className="flex items-center gap-2 mb-3">
                      <Lock className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs text-emerald-400 font-bold">Proof that action is safe</span>
                    </div>
                    <div className="space-y-2">
                      {action.evidence.map((evidence, i) => (
                        <div key={i} className="flex items-start gap-2">
                          <CheckCircle className="w-3 h-3 text-emerald-400 mt-0.5 flex-shrink-0" />
                          <span className="text-xs text-slate-300">{evidence}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="p-4 rounded-xl bg-cyan-500/5 border border-cyan-500/20 text-center">
                      <Target className="w-5 h-5 text-cyan-400 mx-auto mb-2" />
                      <p className="text-xl font-bold text-white">{action.successProbability}%</p>
                      <p className="text-[10px] text-slate-400 font-medium">Success Probability</p>
                    </div>
                    <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20 text-center">
                      <Shield className="w-5 h-5 text-emerald-400 mx-auto mb-2" />
                      <p className="text-xl font-bold text-white">{action.safetyScore}%</p>
                      <p className="text-[10px] text-slate-400 font-medium">Safety Score</p>
                    </div>
                    <div className="p-4 rounded-xl bg-amber-500/5 border border-amber-500/20 text-center">
                      <Clock className="w-5 h-5 text-amber-400 mx-auto mb-2" />
                      <p className="text-xl font-bold text-white">{action.estimatedTime}</p>
                      <p className="text-[10px] text-slate-400 font-medium">Estimated Time</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
