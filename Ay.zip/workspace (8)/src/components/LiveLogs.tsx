import { useState, useEffect, useRef } from 'react';
import { Terminal, Radio, AlertTriangle, Info, Send, Wifi, WifiOff, RefreshCw } from 'lucide-react';

export default function LiveLogs() {
  const [logs, setLogs] = useState<Array<{ type: string; message: string; timestamp: string }>>([]);
  const [manualLog, setManualLog] = useState('');
  const [autoScroll, setAutoScroll] = useState(true);
  const [filter, setFilter] = useState<string>('all');
  const logContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (autoScroll && logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  const sendManualLog = () => {
    if (!manualLog.trim()) return;
    setLogs(prev => [...prev, { type: 'log', message: manualLog, timestamp: new Date().toISOString() }].slice(-200));
    setManualLog('');
  };

  const filteredLogs = filter === 'all' ? logs : logs.filter(l => l.type === filter);

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'risk_alert': return 'border-rose-500/30 bg-rose-500/5';
      case 'action_update': return 'border-purple-500/30 bg-purple-500/5';
      case 'log': return 'border-cyan-500/30 bg-cyan-500/5';
      case 'system_status': return 'border-emerald-500/30 bg-emerald-500/5';
      default: return 'border-slate-700 bg-black/30';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h3 className="text-2xl font-bold text-white flex items-center gap-2">
            <Terminal className="w-6 h-6 text-cyan-400" />
            Real-Time Log Feed
          </h3>
          <p className="text-slate-400 mt-1">Receive and display security logs and events in real-time</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-rose-500/10 border border-rose-500/20">
            <WifiOff className="w-4 h-4 text-rose-400" />
            <span className="text-xs text-rose-400 font-medium">Backend Offline</span>
          </div>
        </div>
      </div>

      <div className="glass-card p-5 border-amber-500/30 bg-amber-500/5">
        <h4 className="text-sm font-bold text-amber-400 mb-3 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4" />
          Backend Not Connected - Setup Instructions
        </h4>
        <div className="terminal space-y-2 text-xs">
          <p className="text-slate-300"># To start the real backend:</p>
          <p className="text-cyan-400">$ cd project-root</p>
          <p className="text-emerald-400">$ npm run server</p>
          <p className="text-slate-400 mt-2"># Or send real logs:</p>
          <p className="text-emerald-400">$ tail -f /var/log/syslog | npx tsx server/ingestion/syslogPipe.ts</p>
          <p className="text-slate-400 mt-2"># Or via curl:</p>
          <p className="text-emerald-400">$ curl -X POST http://localhost:3001/api/logs \</p>
          <p className="text-emerald-400 ml-4">-H "Content-Type: application/json" \</p>
          <p className="text-emerald-400 ml-4">{'-d \'{"logs": ["Jan 1 12:00:00 server sshd: Failed password"], "source": "syslog"}\''}</p>
        </div>
      </div>

      <div className="glass-card p-5">
        <div className="flex items-center gap-2 mb-3">
          <Send className="w-4 h-4 text-cyan-400" />
          <span className="text-sm text-white font-bold">Send Log Manually</span>
        </div>
        <div className="flex gap-2">
          <input
            type="text"
            value={manualLog}
            onChange={(e) => setManualLog(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && sendManualLog()}
            placeholder={'Example: Jan 15 10:30:00 server sshd: Failed password for root from 192.168.1.100'}
            className="flex-1 bg-black/40 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white font-mono placeholder-slate-600 focus:border-cyan-500 focus:outline-none transition-colors"
            dir="ltr"
          />
          <button onClick={sendManualLog} className="px-5 py-2.5 bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 rounded-xl hover:bg-cyan-500/30 transition-colors font-semibold">
            <Send className="w-4 h-4" />
          </button>
        </div>
        <div className="flex gap-2 mt-3">
          <button onClick={() => setManualLog('Jan 15 10:30:00 webserver nginx[1234]: unauthorized access attempt from 10.0.2.50')} className="text-[10px] px-3 py-1.5 rounded-lg bg-slate-800/50 text-slate-400 hover:text-white transition-colors font-medium">
            Example: syslog
          </button>
          <button onClick={() => setManualLog('CRITICAL: SQL injection attempt from 192.168.1.100 targeting /api/users')} className="text-[10px] px-3 py-1.5 rounded-lg bg-slate-800/50 text-slate-400 hover:text-white transition-colors font-medium">
            Example: SQL injection
          </button>
          <button onClick={() => setManualLog('2026-01-15 ERROR malware detected on endpoint-003: trojan.win32.emulate')} className="text-[10px] px-3 py-1.5 rounded-lg bg-slate-800/50 text-slate-400 hover:text-white transition-colors font-medium">
            Example: malware
          </button>
        </div>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs text-slate-400 font-medium">Filter:</span>
        {[
          { key: 'all', label: 'All' },
          { key: 'log', label: 'Logs' },
          { key: 'risk_alert', label: 'Threats' },
          { key: 'action_update', label: 'Actions' },
          { key: 'system_status', label: 'System' },
        ].map((f) => (
          <button key={f.key} onClick={() => setFilter(f.key)} className={`text-[10px] px-3 py-1.5 rounded-lg transition-all font-medium ${filter === f.key ? 'bg-cyan-500/20 text-cyan-400' : 'bg-slate-800/50 text-slate-500 hover:text-white'}`}>
            {f.label}
          </button>
        ))}
        <button onClick={() => setAutoScroll(!autoScroll)} className={`text-[10px] px-3 py-1.5 rounded-lg ml-auto font-medium ${autoScroll ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800/50 text-slate-500'}`}>
          Auto-scroll {autoScroll ? '✓' : ''}
        </button>
        <button onClick={() => setLogs([])} className="text-[10px] px-3 py-1.5 rounded-lg bg-slate-800/50 text-slate-500 hover:text-white font-medium">
          <RefreshCw className="w-3 h-3" />
        </button>
      </div>

      <div ref={logContainerRef} className="glass-card p-5 h-96 overflow-y-auto font-mono text-xs">
        {filteredLogs.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-slate-500">
            <Terminal className="w-10 h-10 mb-3" />
            <p className="text-sm">Waiting for logs...</p>
            <p className="text-[10px] mt-1">Send logs via WebSocket, API, or enter manually above</p>
          </div>
        ) : (
          <div className="space-y-1.5">
            {filteredLogs.map((log, i) => (
              <div key={i} className={`flex items-start gap-2 p-2.5 rounded-lg border ${getTypeColor(log.type)} animate-fade-in`}>
                <span className="text-slate-600 text-[10px] flex-shrink-0 mt-0.5 font-mono">
                  {new Date(log.timestamp).toLocaleTimeString()}
                </span>
                <span className="text-slate-500">[{log.type}]</span>
                <span className="text-slate-300 flex-1">{log.message}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="grid grid-cols-4 gap-4">
        <div className="metric-card"><p className="metric-value">{logs.length}</p><p className="metric-label">Total Events</p></div>
        <div className="metric-card"><p className="metric-value text-rose-400">{logs.filter(l => l.type === 'risk_alert').length}</p><p className="metric-label">Threats Detected</p></div>
        <div className="metric-card"><p className="metric-value text-purple-400">{logs.filter(l => l.type === 'action_update').length}</p><p className="metric-label">Actions Proposed</p></div>
        <div className="metric-card"><p className="metric-value text-cyan-400">{logs.filter(l => l.type === 'log').length}</p><p className="metric-label">Logs Processed</p></div>
      </div>
    </div>
  );
}
