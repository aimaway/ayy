import { Globe, Moon, Bell, Shield, Save } from 'lucide-react';
import { useApp } from '../App';
import type { Language } from '../i18n';

export default function AppSettings() {
  const { language, setLanguage, t } = useApp();

  const languages: { code: Language; label: string; flag: string }[] = [
    { code: 'en', label: t.english, flag: '🇺🇸' },
    { code: 'ar', label: t.arabic, flag: '🇸🇦' },
    { code: 'fr', label: t.french, flag: '🇫🇷' },
  ];

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div>
        <h3 className="text-2xl font-bold text-white mb-2">{t.settings}</h3>
        <p className="text-slate-400">Configure your CyberShield AI platform preferences</p>
      </div>

      {/* Language Selection */}
      <div className="glass-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
            <Globe className="w-5 h-5 text-white" />
          </div>
          <div>
            <h4 className="text-lg font-semibold text-white">{t.language}</h4>
            <p className="text-sm text-slate-400">Choose your preferred language</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {languages.map((lang) => (
            <button
              key={lang.code}
              onClick={() => setLanguage(lang.code)}
              className={`p-4 rounded-xl border-2 transition-all duration-200 ${
                language === lang.code
                  ? 'border-cyan-500 bg-cyan-500/10 shadow-lg shadow-cyan-500/20'
                  : 'border-slate-700 bg-slate-800/30 hover:border-slate-600'
              }`}
            >
              <div className="text-3xl mb-2">{lang.flag}</div>
              <div className="text-white font-semibold">{lang.label}</div>
              {language === lang.code && (
                <div className="text-xs text-cyan-400 mt-1 font-medium">✓ Selected</div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Theme Settings */}
      <div className="glass-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-slate-600 to-slate-800 flex items-center justify-center">
            <Moon className="w-5 h-5 text-white" />
          </div>
          <div>
            <h4 className="text-lg font-semibold text-white">{t.theme}</h4>
            <p className="text-sm text-slate-400">Customize the visual appearance</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 rounded-xl bg-slate-800/30 border border-slate-700">
            <div>
              <div className="text-white font-medium">{t.darkMode}</div>
              <div className="text-sm text-slate-400">Optimized for low-light environments</div>
            </div>
            <div className="w-12 h-6 bg-cyan-500 rounded-full relative cursor-pointer">
              <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full transition-all" />
            </div>
          </div>
        </div>
      </div>

      {/* Notifications */}
      <div className="glass-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center">
            <Bell className="w-5 h-5 text-white" />
          </div>
          <div>
            <h4 className="text-lg font-semibold text-white">{t.notifications}</h4>
            <p className="text-sm text-slate-400">Configure alert preferences</p>
          </div>
        </div>

        <div className="space-y-3">
          {['Critical Alerts', 'High Priority Risks', 'AI Recommendations', 'System Updates'].map((item) => (
            <div key={item} className="flex items-center justify-between p-4 rounded-xl bg-slate-800/30 border border-slate-700">
              <span className="text-white">{item}</span>
              <div className="w-12 h-6 bg-cyan-500 rounded-full relative cursor-pointer">
                <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full transition-all" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scan Configuration */}
      <div className="glass-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div>
            <h4 className="text-lg font-semibold text-white">{t.scanScope}</h4>
            <p className="text-sm text-slate-400">Define authorized scanning boundaries</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Network Range (CIDR)</label>
            <input
              type="text"
              defaultValue="10.0.0.0/16"
              className="w-full px-4 py-3 rounded-xl bg-slate-800/50 border border-slate-700 text-white font-mono focus:border-cyan-500 focus:outline-none transition-colors"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Autonomy Level</label>
            <select className="w-full px-4 py-3 rounded-xl bg-slate-800/50 border border-slate-700 text-white focus:border-cyan-500 focus:outline-none transition-colors">
              <option>Level 1 - Observer Only</option>
              <option>Level 2 - Proposer with Approval</option>
              <option selected>Level 3 - Semi-Autonomous</option>
              <option>Level 4 - Autonomous with Oversight</option>
              <option>Level 5 - Fully Autonomous</option>
            </select>
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button className="btn-primary flex items-center gap-2">
            <Save className="w-4 h-4" />
            {t.save}
          </button>
          <button className="btn-ghost">{t.cancel}</button>
        </div>
      </div>
    </div>
  );
}
