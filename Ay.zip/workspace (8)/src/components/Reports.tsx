import { FileText, Download, Calendar, TrendingUp, Shield, AlertTriangle, CheckCircle, Brain } from 'lucide-react';
import { mockAssets, mockRisks, mockActions, mockTestResults } from '../data';

export default function Reports() {
  const verifiedActions = mockActions.filter(a => a.status === 'verified').length;
  const testsPassed = mockTestResults.filter(t => t.passed).length;
  const totalTests = mockTestResults.length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h3 className="text-2xl font-bold text-white flex items-center gap-2">
            <FileText className="w-6 h-6 text-cyan-400" />
            Evidence-Based Reports
          </h3>
          <p className="text-slate-400 mt-1">Comprehensive report documenting all findings, actions, and results</p>
        </div>
        <button className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold btn-primary">
          <Download className="w-4 h-4" />
          Generate Report
        </button>
      </div>

      <div className="glass-card p-8 border-cyan-500/20">
        <div className="text-center mb-8 pb-6 border-b border-slate-800">
          <div className="flex items-center justify-center gap-3 mb-3">
            <Shield className="w-10 h-10 text-cyan-400" />
            <h2 className="text-2xl font-bold text-white">Cybersecurity Report</h2>
          </div>
          <p className="text-sm text-slate-400">CyberShield AI - Evidence-Based Report</p>
          <div className="flex items-center justify-center gap-2 mt-2">
            <Calendar className="w-3 h-3 text-slate-500" />
            <span className="text-xs text-slate-500">Generated: January 15, 2026</span>
          </div>
        </div>

        <div className="mb-8">
          <h3 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
            <FileText className="w-5 h-5 text-cyan-400" />
            Executive Summary
          </h3>
          <div className="p-5 rounded-xl bg-black/30 border border-slate-800">
            <p className="text-sm text-slate-300 leading-relaxed">
              Scanned <span className="text-cyan-400 font-bold">{mockAssets.length} assets</span> within the authorized scope (10.0.0.0/16). 
              Discovered <span className="text-rose-400 font-bold">{mockRisks.length} security risks</span>, 
              including <span className="text-rose-400 font-bold">{mockRisks.filter(r => r.severity === 'critical').length} critical</span> and 
              <span className="text-amber-400 font-bold"> {mockRisks.filter(r => r.severity === 'high').length} high</span> severity.
              AI generated <span className="text-purple-400 font-bold">{mockActions.length} remediation actions</span>, 
              with <span className="text-emerald-400 font-bold">{verifiedActions}</span> verified successfully in a safe test environment.
              Test success rate: <span className="text-emerald-400 font-bold">{Math.round(testsPassed/totalTests*100)}%</span>.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="p-4 rounded-xl bg-cyan-500/5 border border-cyan-500/20 text-center">
            <p className="text-2xl font-bold text-cyan-400">{mockAssets.length}</p>
            <p className="text-[10px] text-slate-400 font-medium">Assets Scanned</p>
          </div>
          <div className="p-4 rounded-xl bg-rose-500/5 border border-rose-500/20 text-center">
            <p className="text-2xl font-bold text-rose-400">{mockRisks.length}</p>
            <p className="text-[10px] text-slate-400 font-medium">Risks Found</p>
          </div>
          <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20 text-center">
            <p className="text-2xl font-bold text-emerald-400">{verifiedActions}</p>
            <p className="text-[10px] text-slate-400 font-medium">Actions Verified</p>
          </div>
          <div className="p-4 rounded-xl bg-purple-500/5 border border-purple-500/20 text-center">
            <p className="text-2xl font-bold text-purple-400">{Math.round(testsPassed/totalTests*100)}%</p>
            <p className="text-[10px] text-slate-400 font-medium">Test Success</p>
          </div>
        </div>

        <div className="mb-8">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-rose-400" />
            Key Findings
          </h3>
          <div className="space-y-2">
            {mockRisks.sort((a, b) => b.priority - a.priority).slice(0, 4).map((risk, i) => (
              <div key={risk.id} className="flex items-center gap-3 p-4 rounded-xl bg-black/30 border border-slate-800/50">
                <span className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold ${risk.severity === 'critical' ? 'bg-rose-500/20 text-rose-400' : risk.severity === 'high' ? 'bg-amber-500/20 text-amber-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                  {i + 1}
                </span>
                <div className="flex-1">
                  <p className="text-sm text-white font-medium">{risk.title}</p>
                  <p className="text-[10px] text-slate-500">CVSS: {risk.cvssScore} | Priority: {risk.priority}</p>
                </div>
                <span className={`text-[10px] px-2 py-1 rounded-lg font-semibold ${risk.severity === 'critical' ? 'bg-rose-500/10 text-rose-400' : risk.severity === 'high' ? 'bg-amber-500/10 text-amber-400' : 'bg-yellow-500/10 text-yellow-400'}`}>
                  {risk.severity.toUpperCase()}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="mb-8">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-emerald-400" />
            Actions Taken & Evidence
          </h3>
          <div className="space-y-3">
            {mockActions.filter(a => a.status === 'verified').map((action) => (
              <div key={action.id} className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
                <div className="flex items-center gap-2 mb-3">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span className="text-sm font-bold text-white">{action.title}</span>
                </div>
                <div className="space-y-1.5 ml-6">
                  {action.evidence.map((evidence, i) => (
                    <p key={i} className="text-xs text-slate-400 flex items-center gap-2">
                      <span className="text-emerald-400">•</span> {evidence}
                    </p>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-cyan-400" />
            Recommendations
          </h3>
          <div className="p-5 rounded-xl bg-black/30 border border-slate-800">
            <ul className="space-y-3">
              {['Increase autonomy level to 4 after proving consistent accuracy for 30 days', 'Conduct monthly comprehensive scans with expanded cloud environment coverage', 'Implement 24/7 continuous monitoring with automatic alerts for critical risks', 'Train team on handling AI recommendations and reducing approval time'].map((rec, i) => (
                <li key={i} className="text-sm text-slate-300 flex items-start gap-3">
                  <span className="text-cyan-400 font-bold">{i + 1}.</span>
                  {rec}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
