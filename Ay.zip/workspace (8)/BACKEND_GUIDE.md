# CyberShield AI - Backend Setup Guide

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    CyberShield AI System                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────────┐  │
│  │   Frontend   │◄──►│   REST API   │◄──►│    SQLite DB     │  │
│  │  (React/Vite)│    │  (Express)   │    │  (cybershield.db)│  │
│  └──────┬───────┘    └──────┬───────┘    └──────────────────┘  │
│         │                   │                                    │
│         │    ┌──────────────┘                                    │
│         │    │                                                    │
│  ┌──────▼────▼────┐    ┌──────────────┐    ┌──────────────────┐ │
│  │   WebSocket    │    │ Log Ingestion│    │   AI Predictor   │ │
│  │   (Real-time)  │    │   Pipeline   │    │    Engine        │ │
│  └────────────────┘    └──────────────┘    └──────────────────┘ │
│                                                                  │
│  Data Sources:                                                   │
│  • Syslog feeds     • SIEM exports     • API integrations       │
│  • File watchers    • WebSocket streams • Manual input          │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## 🚀 Quick Start

### 1. Install Dependencies

```bash
# Frontend dependencies (already installed)
npm install

# Server dependencies (already installed)
# express, ws, better-sqlite3, cors, helmet, uuid, winston
```

### 2. Start the Backend Server

```bash
# Using tsx (recommended for development)
npx tsx server/index.ts

# Or compile and run
npx tsc -p tsconfig.server.json
node dist-server/index.js
```

The server will start on `http://localhost:3001`

### 3. Start the Frontend

```bash
npm run dev
```

### 4. Connect Them

The frontend will automatically connect to the backend via:
- REST API: `http://localhost:3001/api`
- WebSocket: `ws://localhost:3001/ws`

---

## 📡 Sending Real Data to the Backend

### Method 1: HTTP API (REST)

#### Send a single log:
```bash
curl -X POST http://localhost:3001/api/logs \
  -H "Content-Type: application/json" \
  -d '{
    "rawLog": "Jan 15 10:30:00 webserver nginx[1234]: unauthorized access attempt from 10.0.2.50",
    "source": "nginx"
  }'
```

#### Send batch logs:
```bash
curl -X POST http://localhost:3001/api/logs \
  -H "Content-Type: application/json" \
  -d '{
    "logs": [
      "Jan 15 10:30:00 server sshd[1234]: Failed password for root from 192.168.1.100",
      "{\"severity\":\"critical\",\"message\":\"CVE-2024-7262 exploit detected\",\"source_ip\":\"10.0.1.50\"}",
      "2026-01-15 ERROR malware detected: trojan.win32 on endpoint-003"
    ],
    "source": "siem-export"
  }'
```

#### Register an asset:
```bash
curl -X POST http://localhost:3001/api/assets \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Production Web Server",
    "type": "server",
    "ip": "10.0.1.10",
    "os": "Ubuntu 22.04",
    "criticality": "critical",
    "status": "active",
    "openPorts": [22, 80, 443],
    "services": ["nginx", "node.js", "ssh"]
  }'
```

#### Trigger AI processing:
```bash
curl -X POST http://localhost:3001/api/ai/process-risks
```

### Method 2: WebSocket (Real-time)

```javascript
// Connect to WebSocket
const ws = new WebSocket('ws://localhost:3001/ws');

// Send a log
ws.send(JSON.stringify({
  type: 'log',
  payload: 'Jan 15 10:30:00 server sshd[1234]: Failed password for root from 192.168.1.100'
}));

// Send batch
ws.send(JSON.stringify({
  type: 'batch_logs',
  payload: ['log1', 'log2', 'log3']
}));

// Trigger AI scan
ws.send(JSON.stringify({ type: 'trigger_scan' }));

// Listen for events
ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('Event:', data.type, data.payload);
};
```

### Method 3: Pipe System Logs Directly

```bash
# Linux syslog
tail -f /var/log/syslog | nc localhost 3001

# Or with a simple script
tail -f /var/log/auth.log | while read line; do
  curl -s -X POST http://localhost:3001/api/logs \
    -H "Content-Type: application/json" \
    -d "{\"rawLog\": \"$line\", \"source\": \"auth.log\"}" > /dev/null
done

# Nginx access logs
tail -f /var/log/nginx/access.log | while read line; do
  curl -s -X POST http://localhost:3001/api/logs \
    -H "Content-Type: application/json" \
    -d "{\"rawLog\": \"$line\", \"source\": \"nginx\"}" > /dev/null
done
```

### Method 4: SIEM Integration

Most SIEMs (Splunk, Elastic, QRadar) can forward logs via HTTP:

**Splunk HEC:**
```
Configure HTTP Event Collector to forward to:
http://your-server:3001/api/logs
```

**Elastic Logstash:**
```ruby
output {
  http {
    url => "http://your-server:3001/api/logs"
    http_method => "post"
    format => "json"
    mapping => {
      "logs" => ["%{message}"]
      "source" => "%{host}"
    }
  }
}
```

---

## 🗄️ Database Schema

The system uses SQLite with the following tables:

| Table | Description |
|-------|-------------|
| `assets` | Discovered assets in the authorized scope |
| `risks` | Identified security risks/vulnerabilities |
| `ai_actions` | AI-generated remediation actions |
| `test_results` | Sandbox test results for actions |
| `log_entries` | All ingested log entries |
| `scan_results` | Vulnerability scan results |
| `autonomy_metrics` | Metrics for each autonomy level |
| `system_config` | System configuration |
| `log_sources` | Configured log sources |

Database file: `data/cybershield.db`

---

## 🤖 AI Prediction Engine

The AI engine follows this pipeline:

```
Incoming Log → Parse & Classify → Match Asset → Create Risk
                                                    ↓
Open Risk → Find Action Template → Calculate Confidence
                                        ↓
                              Calculate Safety Score
                                        ↓
                              Calculate Autonomy Level
                                        ↓
                              Generate Evidence
                                        ↓
                              Run Sandbox Tests
                                        ↓
                              Produce Report
```

### Action Templates

The engine has templates for:
- **RCE/Exploits** → Patch actions
- **SQL Injection** → WAF + parameterized queries
- **Unauthorized Access** → Account lockout + IP blocking
- **Malware** → Isolation + remediation
- **Misconfigurations** → CIS benchmark hardening
- **Port Scans** → Monitoring + port closure

---

## 🔐 API Endpoints Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Health check |
| GET | `/api/dashboard/stats` | Dashboard statistics |
| GET | `/api/assets` | List all assets |
| POST | `/api/assets` | Register new asset |
| PUT | `/api/assets/:id` | Update asset |
| GET | `/api/risks` | List all risks |
| PUT | `/api/risks/:id/status` | Update risk status |
| GET | `/api/actions` | List AI actions |
| PUT | `/api/actions/:id/status` | Update action status |
| POST | `/api/ai/process-risks` | Trigger AI processing |
| POST | `/api/ai/generate-action/:riskId` | Generate action for risk |
| POST | `/api/testing/run/:actionId` | Run safety tests |
| GET | `/api/testing/results/:actionId` | Get test results |
| GET | `/api/logs` | Get recent logs |
| POST | `/api/logs` | **Ingest logs (main entry)** |
| GET | `/api/config` | Get system config |
| PUT | `/api/config/autonomy` | Set autonomy level |
| PUT | `/api/config/scope` | Set authorized scope |

---

## 📊 Log Format Support

The system accepts logs in these formats:

### JSON
```json
{
  "timestamp": "2026-01-15T10:30:00Z",
  "severity": "error",
  "source_ip": "192.168.1.100",
  "destination_ip": "10.0.1.10",
  "message": "SQL injection attempt detected: UNION SELECT..."
}
```

### Syslog
```
Jan 15 10:30:00 hostname program[1234]: message content here
```

### Raw Text
```
2026-01-15 ERROR Connection from 192.168.1.100 blocked by firewall
```

### Auto-Detection
The parser automatically:
- Detects log format (JSON/Syslog/Raw)
- Extracts IP addresses
- Identifies severity levels
- Matches vulnerability patterns
- Associates with known assets
- Creates risks when threats are detected

---

## 🧪 Testing the Integration

### Test 1: Send a simulated attack log
```bash
curl -X POST http://localhost:3001/api/logs \
  -H "Content-Type: application/json" \
  -d '{"rawLog": "CRITICAL: SQL injection attempt from 10.0.2.100 targeting /api/users?id=1 OR 1=1", "source": "waf"}'
```

### Test 2: Check if risk was created
```bash
curl http://localhost:3001/api/risks | jq '.data[0]'
```

### Test 3: Trigger AI to generate action
```bash
curl -X POST http://localhost:3001/api/ai/process-risks | jq '.data'
```

### Test 4: Run safety tests
```bash
# Get the action ID first
ACTION_ID=$(curl -s http://localhost:3001/api/actions | jq -r '.data[0].id')
curl -X POST http://localhost:3001/api/testing/run/$ACTION_ID | jq '.data'
```

---

## 🔄 Production Deployment

### Environment Variables
```bash
PORT=3001                    # Server port
HOST=0.0.0.0                # Bind address
NODE_ENV=production          # Environment
VITE_API_URL=http://your-domain:3001/api    # Frontend API URL
VITE_WS_URL=ws://your-domain:3001/ws        # Frontend WebSocket URL
```

### Docker (example)
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY . .
RUN npx tsc -p tsconfig.server.json
EXPOSE 3001
CMD ["node", "dist-server/index.js"]
```

### Systemd Service
```ini
[Unit]
Description=CyberShield AI Backend
After=network.target

[Service]
Type=simple
User=cybershield
WorkingDirectory=/opt/cybershield
ExecStart=/usr/bin/npx tsx server/index.ts
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

---

## 📈 What Makes This Real (Not Simulated)

1. **Real Database**: SQLite stores all data persistently
2. **Real Log Parsing**: Actual syslog/JSON parsing with pattern matching
3. **Real Risk Detection**: Pattern-based vulnerability identification
4. **Real AI Pipeline**: Template-based action generation with scoring
5. **Real WebSocket**: Live bidirectional communication
6. **Real API**: Full REST API with CRUD operations
7. **Real Testing**: Sandbox test execution framework
8. **Real Metrics**: Autonomy level calculation based on actual data

The system is waiting for YOUR real data to flow in. Once connected to actual log sources, it will:
- Discover real assets from network scans
- Detect real vulnerabilities from security tools
- Generate real remediation actions based on actual risks
- Test actions in real sandbox environments
- Produce evidence-based reports from actual findings
